package com.kots.sidim.android.exception;

public class SiDIMException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SiDIMException(String string) {
		super(string);
	}

}
